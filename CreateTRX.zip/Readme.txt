The DLL file version might have to be the same as the TestStudio that's installed on the server that runs this program.

