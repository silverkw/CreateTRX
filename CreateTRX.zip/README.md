# CreateTRX
CreateTRX file from Telerik TestStudio result file
